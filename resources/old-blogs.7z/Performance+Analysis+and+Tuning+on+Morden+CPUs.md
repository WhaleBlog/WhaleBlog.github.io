---
title: Performance Analysis and Tuning on Morden CPUs
id: 0604d9d2-5b36-42c0-8c6d-eb2c3cb5572b
date: 2024-12-07 01:46:33
auther: admin
cover: 
excerpt: 
permalink: /archives/performance-analysis-and-tuning-on-morden-cpus
categories:
tags: 
---

写得有点乱......等有经验之后再来优化一下吧

![](/upload/性能分析方法.png)

![](/upload/基于源代码的CPU调优%20conv%201.png)